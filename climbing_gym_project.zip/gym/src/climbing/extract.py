import pandas as pd

from .config import RAW_PATH


def extract(path=RAW_PATH) -> pd.DataFrame:
    """Read the raw Google Forms export exactly as-is."""
    return pd.read_csv(path)
