import sqlite3

import pandas as pd

from .config import PROCESSED_DIR


def load(df: pd.DataFrame, traits: pd.DataFrame, out_dir=PROCESSED_DIR) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / "responses_clean.csv", index=False)
    traits.to_csv(out_dir / "respondent_traits.csv", index=False)
    df.to_parquet(out_dir / "responses_clean.parquet", index=False)
    with sqlite3.connect(out_dir / "survey.db") as con:
        df.drop(columns=["experience_traits"]).to_sql("respondents", con, if_exists="replace", index=False)
        traits.to_sql("respondent_traits", con, if_exists="replace", index=False)
