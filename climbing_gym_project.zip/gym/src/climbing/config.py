"""Paths and constants shared across the pipeline."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW_PATH = ROOT / "data" / "raw" / "responses.csv"
PROCESSED_DIR = ROOT / "data" / "processed"
FIGURES_DIR = ROOT / "reports" / "figures"

LIKERT = {"Strongly Disagree": 1, "Disagree": 2, "Neutral": 3, "Agree": 4, "Strongly Agree": 5}
TRAVEL_ORDER = ["Less than 15 minutes", "15-30 minutes", "30-45 minutes",
                "45-60 minutes", "More than 60 minutes"]
AGE_ORDER = ["Under 20", "20s", "30s", "40s", "50s", "60s", "Over 60"]
EXPERIENCE_ORDER = ["Less than 1 year", "1-3 years", "3-5 years", "5-10 years", "More than 10 years"]

# Substring of the long Google Forms question -> short column name
RENAME = {
    "Timestamp": "submitted_at",
    "travel one way": "travel_time",
    "How often do you go": "visits_per_week",
    "hours per visit": "hours_per_visit",
    "meaningful friendships": "likert_friendships",
    "sense of belonging": "likert_belonging",
    "even when I am not actively climbing": "likert_enjoy_not_climbing",
    "socialize with other climbers outside": "likert_socialize_outside",
    "important part of my social life": "likert_social_life",
    "without needing to make specific plans": "likert_comfortable_alone",
    "describes your experience": "experience_traits",
    "your third place": "is_third_place",
    "Why and how did you get into": "story",
}
