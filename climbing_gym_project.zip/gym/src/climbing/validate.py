import pandas as pd


def validate(df: pd.DataFrame, traits: pd.DataFrame, expected_rows: int | None = None) -> None:
    """Raise AssertionError if the cleaned data breaks an expectation."""
    if expected_rows is not None:
        assert len(df) == expected_rows, f"expected {expected_rows} rows, got {len(df)}"
    assert df["respondent_id"].is_unique, "respondent_id must be unique"
    assert df["is_third_place"].notna().all(), "is_third_place has missing values"
    assert df["visits_per_week"].dropna().between(0, 7).all(), "visits_per_week out of range"
    assert df["hours_per_visit"].dropna().between(0, 12).all(), "hours_per_visit out of range"
    assert df["social_score"].dropna().between(1, 5).all(), "social_score out of range"
    assert set(traits["respondent_id"]) <= set(df["respondent_id"]), "orphan trait rows"
