import re

import pandas as pd

from .config import (AGE_ORDER, EXPERIENCE_ORDER, LIKERT, RENAME, TRAVEL_ORDER)


def collapse_grid(df: pd.DataFrame, prefix: str, new_col: str, order: list) -> pd.DataFrame:
    """Turn a one-column-per-option grid ('Question [20s]') into one ordered column."""
    cols = [c for c in df.columns if c.startswith(prefix)]
    labels = {c: re.search(r"\[(.*)\]", c).group(1).strip() for c in cols}
    grid = df[cols].rename(columns=labels).notna()
    df[new_col] = grid.idxmax(axis=1).where(grid.any(axis=1))  # NaN if nothing ticked
    df[new_col] = pd.Categorical(df[new_col], categories=order, ordered=True)
    return df.drop(columns=cols)


def rename_columns(df: pd.DataFrame) -> pd.DataFrame:
    new_names = {}
    for col in df.columns:
        for key, name in RENAME.items():
            if key.lower() in col.lower():
                new_names[col] = name
                break
    return df.rename(columns=new_names)


def transform(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = collapse_grid(df, "What is your age group?", "age_group", AGE_ORDER)
    df = collapse_grid(df, "How long have you been climbing?", "climbing_experience", EXPERIENCE_ORDER)
    df = rename_columns(df)

    df["submitted_at"] = pd.to_datetime(df["submitted_at"], format="%m/%d/%Y %H:%M:%S")
    df["travel_time"] = pd.Categorical(df["travel_time"], categories=TRAVEL_ORDER, ordered=True)
    df["is_third_place"] = df["is_third_place"].map({"Yes": True, "No": False})

    likert_cols = [c for c in df.columns if c.startswith("likert_")]
    for c in likert_cols:
        df[c] = df[c].map(LIKERT).astype("Int64")
    df["social_score"] = df[likert_cols].mean(axis=1).round(2)

    df["story"] = df["story"].str.strip().replace("", pd.NA)
    df.insert(0, "respondent_id", range(1, len(df) + 1))
    return df


def build_traits_table(df: pd.DataFrame) -> pd.DataFrame:
    """Checkbox answers -> one row per (respondent, trait)."""
    traits = (df.set_index("respondent_id")["experience_traits"].dropna()
              .str.split(r"\.,\s*").explode().str.strip().str.rstrip("."))
    return traits.rename("trait").reset_index()
