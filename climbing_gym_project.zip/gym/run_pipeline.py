"""Run the full ETL: raw CSV -> cleaned tables, Parquet and SQLite."""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from climbing.extract import extract
from climbing.load import load
from climbing.transform import build_traits_table, transform
from climbing.validate import validate

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("pipeline")

if __name__ == "__main__":
    raw = extract()
    log.info("extracted %d rows, %d columns", *raw.shape)
    clean = transform(raw)
    traits = build_traits_table(clean)
    log.info("transformed: %d respondents, %d trait rows", len(clean), len(traits))
    validate(clean, traits)
    log.info("validation passed")
    load(clean, traits)
    log.info("loaded to data/processed/")
